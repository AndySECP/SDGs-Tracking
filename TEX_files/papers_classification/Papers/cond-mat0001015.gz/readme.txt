%auto-ignore 

The text is generated using Scientific Word 2.0. The figures may not be
reproduced properly even under scientific word 2.0 due to wrong path.